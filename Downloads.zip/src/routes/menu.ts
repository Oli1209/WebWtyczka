/**
 * Menu page — PROMPT 4. Editorial, data-driven rendering from src/data/menu.ts.
 * Preserves source names/descriptions/prices/order exactly. DQ markers are internal only.
 */
import { menuData, type MenuCategory, type AdditionGroup } from '../data/menu';

function esc(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function renderItem(catId: string, name: string, price: string, description?: string): string {
  return `
    <article class="menu-item">
      <div class="menu-item__head">
        <h3 class="menu-item__name">${esc(name)}</h3>
        <p class="menu-item__price" aria-label="Cena: ${esc(price)}">${esc(price)}</p>
      </div>
      ${description ? `<p class="menu-item__desc">${esc(description)}</p>` : ''}
    </article>`;
}

function renderCategory(cat: MenuCategory, index: number): string {
  const surface = index % 3 === 1 ? ' menu-section--warm' : index % 3 === 2 ? ' menu-section--tint' : '';
  const pizzaNote = cat.id === 'pizza'
    ? `<p class="menu-section__note">Pizze oznaczone jako <span lang="it">(bianca)</span> podawane są bez sosu pomidorowego. Dodatki do pizz znajdziesz poniżej.</p>`
    : '';
  const items = cat.items.map((it) => renderItem(cat.id, it.name, it.price, it.description)).join('');
  const listClass = cat.id === 'pizza' ? 'menu-items menu-items--pizza' : 'menu-items';
  return `
    <section class="menu-section${surface}" id="${esc(cat.id)}" aria-labelledby="${esc(cat.id)}-title" data-menu-section>
      <div class="container menu-section__inner">
        <header class="menu-section__header">
          <p class="menu-section__number" aria-hidden="true">${esc(cat.number)}</p>
          <div>
            <h2 id="${esc(cat.id)}-title" class="menu-section__title">${esc(cat.name)}</h2>
            ${cat.subtitle ? `<p class="menu-section__subtitle">${esc(cat.subtitle)}</p>` : ''}
          </div>
        </header>
        ${pizzaNote}
        <div class="${listClass}">
          ${items}
        </div>
      </div>
    </section>`;
}

function renderAdditionGroup(group: AdditionGroup): string {
  const list = group.items.map((i) => `<li>${esc(i)}</li>`).join('');
  return `
    <article class="menu-addition" aria-label="Dodatki ${esc(group.price)}">
      <h3 class="menu-addition__price">${esc(group.price)}</h3>
      <ul class="menu-addition__list">${list}</ul>
    </article>`;
}

export function renderMenuPage(): string {
  const nav = menuData.categories
    .map((c) => `<a class="menu-nav__link" href="#${esc(c.id)}" data-menu-nav="${esc(c.id)}">${esc(c.number)} ${esc(c.name)}</a>`)
    .join('');
  const sections = menuData.categories.map((c, i) => renderCategory(c, i)).join('');
  const additions = menuData.additionGroups.map(renderAdditionGroup).join('');
  const notes = menuData.menuNotes.map((n) => `<li>${esc(n)}</li>`).join('');

  return `
    <main id="main-content" tabindex="-1" class="menu-page">
      <section class="menu-hero" aria-labelledby="menu-title">
        <div class="container menu-hero__inner">
          <div class="menu-hero__copy">
            <p class="menu-kicker">Farina Wieluń</p>
            <h1 id="menu-title" class="menu-hero__title">Menu</h1>
            <p class="menu-hero__lead">Pasta, pizza, sałatki, desery, kawa i napoje — w jednej karcie, ułożonej tak, żeby łatwo było wrócić do ulubionej kategorii albo spokojnie przejrzeć całość.</p>
          </div>
          <div class="menu-hero__meta">
            <p><strong>${menuData.categories.length}</strong> kategorii</p>
            <p><strong>${menuData.categories.reduce((n, c) => n + c.items.length, 0)}</strong> pozycji w karcie</p>
            <p class="menu-hero__hint">Nazwy, opisy i ceny podajemy zgodnie z dostępnymi danymi karty. Informacje o alergenach można uzyskać u obsługi lokalu.</p>
          </div>
        </div>
      </section>

      <nav class="menu-nav" aria-label="Kategorie menu">
        <div class="container">
          <div class="menu-nav__scroller">
            ${nav}
            <a class="menu-nav__link menu-nav__link--extra" href="#dodatki-do-pizz" data-menu-nav="dodatki-do-pizz">Dodatki do pizz</a>
          </div>
        </div>
      </nav>

      <div class="menu-sections">
        ${sections}
      </div>

      <section class="menu-section menu-additions" id="dodatki-do-pizz" aria-labelledby="dodatki-title" data-menu-section>
        <div class="container menu-additions__inner">
          <header class="menu-section__header menu-section__header--compact">
            <p class="menu-section__number" aria-hidden="true">+</p>
            <div>
              <h2 id="dodatki-title" class="menu-section__title">Dodatki do pizz</h2>
              <p class="menu-section__subtitle">dodatkowe składniki według grup cenowych</p>
            </div>
          </header>
          <div class="menu-additions__grid">
            ${additions}
          </div>
          <ul class="menu-notes" aria-label="Informacje dodatkowe">
            ${notes}
          </ul>
        </div>
      </section>

      <section class="menu-close" aria-labelledby="menu-close-title">
        <div class="container menu-close__inner">
          <div>
            <p class="menu-kicker">Wizyta</p>
            <h2 id="menu-close-title" class="menu-close__title">Masz pytanie o kartę lub wizytę?</h2>
          </div>
          <div class="menu-close__actions">
            <a class="btn btn--primary" href="/kontakt/">Kontakt</a>
            <a class="btn btn--secondary" href="tel:+48729883035">Zadzwoń</a>
          </div>
        </div>
      </section>
    </main>`;
}

export function initMenuPage(): void {
  const nav = document.querySelector<HTMLElement>('.menu-nav');
  const links = Array.from(document.querySelectorAll<HTMLAnchorElement>('[data-menu-nav]'));
  const sections = Array.from(document.querySelectorAll<HTMLElement>('[data-menu-section]'));
  if (!nav || !links.length || !sections.length) return;

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const headerOffset = () => {
    const header = document.querySelector<HTMLElement>('.site-header');
    return (header?.getBoundingClientRect().height ?? 72) + (nav.getBoundingClientRect().height ?? 52) + 12;
  };

  links.forEach((link) => {
    link.addEventListener('click', (e) => {
      const id = link.getAttribute('href')?.slice(1);
      const target = id ? document.getElementById(id) : null;
      if (!target) return;
      e.preventDefault();
      const top = target.getBoundingClientRect().top + window.scrollY - headerOffset();
      window.scrollTo({ top, behavior: reduceMotion ? 'auto' : 'smooth' });
      history.pushState(null, '', `#${id}`);
    });
  });

  if (!('IntersectionObserver' in window)) return;
  const byId = new Map(links.map((l) => [l.dataset.menuNav, l]));
  const observer = new IntersectionObserver(
    (entries) => {
      const visible = entries
        .filter((e) => e.isIntersecting)
        .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (!visible) return;
      const id = (visible.target as HTMLElement).id;
      links.forEach((l) => l.removeAttribute('aria-current'));
      const active = byId.get(id);
      if (active) {
        active.setAttribute('aria-current', 'location');
        active.scrollIntoView({ block: 'nearest', inline: 'center', behavior: reduceMotion ? 'auto' : 'smooth' });
      }
    },
    { rootMargin: '-25% 0px -60% 0px', threshold: [0.01, 0.2, 0.5] },
  );
  sections.forEach((s) => observer.observe(s));
}
