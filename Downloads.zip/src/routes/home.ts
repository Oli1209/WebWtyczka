/**
 * Home page — PROMPT 3. Original Polish copy; verified facts only.
 * No invented history/claims/hours/ordering/testimonials. No DQ-09/11 featured.
 * Conditional flavours preview follows FW-30 (text-led fallback; no fake signature claims).
 */

function esc(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

const VERIFIED = {
  name: 'Farina Wieluń',
  addressLine1: 'Kopernika 29',
  addressLine2: '98-300 Wieluń',
  addressFull: 'Kopernika 29, 98-300 Wieluń',
  phoneDisplay: '+48 729 883 035',
  phoneHref: 'tel:+48729883035',
  directionsHref:
    'https://www.google.com/maps/search/?api=1&query=Farina+Wielu%C5%84+Kopernika+29+98-300+Wielu%C5%84',
} as const;

// Verified menu examples from Farina - Menu Source Data. No DQ-09/11 items.
const flavourExamples = [
  {
    name: 'BRUSCHETTA AL POMODORO (3 szt.)',
    price: '16 zł',
    desc: 'Grzanki, pomidory, czosnek, oliwa extra vergine, oregano.',
  },
  {
    name: 'SPAGHETTI ALLA CARBONARA',
    price: '38 zł',
    desc: 'Quanciale, żółtko, Grana Padano, pieprz.',
  },
  {
    name: 'MARGHERITA',
    price: '30 zł',
    desc: 'Sos pomidorowy, mozzarella, bazylia.',
  },
  {
    name: 'Tiramisu in Coppa',
    price: '15 zł',
    desc: 'Biszkopty, kawa, mascarpone.',
  },
] as const;

export function renderHomePage(): string {
  const flavours = flavourExamples
    .map(
      (item) => `
        <article class="home-flavour">
          <h3 class="home-flavour__name">${esc(item.name)}</h3>
          <p class="home-flavour__price">${esc(item.price)}</p>
          <p class="home-flavour__desc">${esc(item.desc)}</p>
        </article>`,
    )
    .join('');

  return `
    <main id="main-content" tabindex="-1" class="home">
      <section class="home-hero" aria-labelledby="home-hero-title">
        <div class="container home-hero__grid">
          <div class="home-hero__copy">
            <p class="home-hero__eyebrow">Farina Wieluń · pasta e pizza</p>
            <h1 id="home-hero-title" class="home-hero__title">Włoska kuchnia, <em>wspólny stół</em> i czas dla siebie.</h1>
            <p class="home-hero__lead">Pasta, pizza i dania inspirowane włoską kuchnią — w miejscu, do którego można wpaść na codzienny obiad, spotkanie albo dłuższą rozmowę przy stole.</p>
            <div class="home-hero__actions">
              <a class="btn btn--primary" href="/menu/">Zobacz menu</a>
              <a class="btn btn--secondary" href="/kontakt/">Kontakt i dojazd</a>
            </div>
          </div>
          <aside class="home-hero__aside" aria-label="Podstawowe informacje">
            <dl>
              <div class="home-hero__fact">
                <dt>Adres</dt>
                <dd>${esc(VERIFIED.addressLine1)}<br />${esc(VERIFIED.addressLine2)}</dd>
              </div>
              <div class="home-hero__fact">
                <dt>Telefon</dt>
                <dd><a href="${VERIFIED.phoneHref}">${esc(VERIFIED.phoneDisplay)}</a></dd>
              </div>
              <div class="home-hero__fact">
                <dt>Godziny</dt>
                <dd>Aktualne godziny otwarcia warto potwierdzić telefonicznie.</dd>
              </div>
            </dl>
          </aside>
        </div>
      </section>

      <section class="home-section" aria-labelledby="home-intro-title">
        <div class="container home-intro">
          <div>
            <p class="home-kicker">O Farinie</p>
            <h2 id="home-intro-title" class="home-heading">Miejsce z włoską kuchnią i spokojnym, gościnnym charakterem.</h2>
            <p class="home-lead">Farina to lokal w Wieluniu, w którym ważne są smak jedzenia, swobodna atmosfera i zwyczajna przyjemność bycia przy stole. Karta łączy klasyczne włoskie kierunki — od antipasti i makaronów, przez pizzę, po desery i napoje.</p>
            <p class="home-body">Strona pokazuje najważniejsze informacje praktyczne i pomaga szybko przejść do menu. Tam znajdziesz pełną kartę dań i napojów.</p>
          </div>
          <aside class="home-intro__aside" aria-label="Myśl przewodnia">
            <p>Proste informacje, czytelne menu i pierwsze wrażenie, które oddaje charakter miejsca — bez zbędnego nadmiaru.</p>
          </aside>
        </div>
      </section>

      <section class="home-section home-section--warm" aria-labelledby="home-pathways-title">
        <div class="container">
          <p class="home-kicker">Menu</p>
          <h2 id="home-pathways-title" class="home-heading">Od przystawki po deser.</h2>
          <p class="home-lead">Pełna karta czeka na osobnej stronie. Poniżej kilka naturalnych punktów startu.</p>
          <div class="home-pathways" aria-label="Ścieżki do menu">
            <a class="home-pathway" href="/menu/"><span class="home-pathway__name">Antipasti</span><span class="home-pathway__meta">Zobacz menu</span></a>
            <a class="home-pathway" href="/menu/"><span class="home-pathway__name">Pasta</span><span class="home-pathway__meta">Zobacz menu</span></a>
            <a class="home-pathway" href="/menu/"><span class="home-pathway__name">Pizza</span><span class="home-pathway__meta">Zobacz menu</span></a>
            <a class="home-pathway" href="/menu/"><span class="home-pathway__name">Desery</span><span class="home-pathway__meta">Zobacz menu</span></a>
            <a class="home-pathway" href="/menu/"><span class="home-pathway__name">Napoje</span><span class="home-pathway__meta">Zobacz menu</span></a>
          </div>
        </div>
      </section>

      <section class="home-section" aria-labelledby="home-flavours-title">
        <div class="container">
          <p class="home-kicker">Wybrane smaki</p>
          <h2 id="home-flavours-title" class="home-heading">Kilka dań z karty.</h2>
          <p class="home-lead">To krótki przegląd przykładowych pozycji z różnych części menu. Nazwy, opisy i ceny pochodzą z aktualnie dostępnych danych karty; pełny wybór znajdziesz na stronie menu.</p>
          <div class="home-flavours">
            ${flavours}
          </div>
          <div class="home-section__actions">
            <a class="btn btn--primary" href="/menu/">Przejdź do pełnego menu</a>
          </div>
        </div>
      </section>

      <section class="home-section home-section--wine" aria-labelledby="home-atmosphere-title">
        <div class="container home-atmosphere">
          <div>
            <p class="home-kicker">Atmosfera</p>
            <h2 id="home-atmosphere-title" class="home-heading">Włoska kuchnia smakuje najlepiej, gdy jest czas, żeby przy niej zostać.</h2>
            <p class="home-body">Farina kojarzy się z jedzeniem, które łączy ludzi przy jednym stole — od szybkiej wizyty po spokojniejsze spotkanie. Ten klimat chcemy oddać prostym układem, ciepłą typografią i czytelnymi informacjami.</p>
          </div>
          <div class="home-atmosphere__quote">
            <p>Dobry lokal poznaje się nie po haśle, ale po tym, czy chce się wrócić do menu i sprawdzić, co jest na stole.</p>
          </div>
        </div>
      </section>

      <section class="home-section home-section--warm" aria-labelledby="home-visit-title">
        <div class="container home-visit">
          <div>
            <p class="home-kicker">Wizyta</p>
            <h2 id="home-visit-title" class="home-heading">Adres, telefon i szybka droga do kontaktu.</h2>
            <p class="home-lead">Jeśli planujesz wizytę, najprościej zadzwonić i potwierdzić aktualne godziny otwarcia lub sprawdzić szczegóły na stronie kontaktowej.</p>
            <div class="home-visit__actions">
              <a class="btn btn--primary" href="/kontakt/">Strona kontaktowa</a>
              <a class="btn btn--secondary" href="/menu/">Zobacz menu</a>
            </div>
          </div>
          <div class="home-visit__card" aria-label="Dane lokalu">
            <h3>${esc(VERIFIED.name)}</h3>
            <ul class="home-visit__list">
              <li><span class="home-visit__label">Adres</span><span>${esc(VERIFIED.addressFull)}</span></li>
              <li><span class="home-visit__label">Telefon</span><a href="${VERIFIED.phoneHref}">${esc(VERIFIED.phoneDisplay)}</a></li>
              <li><span class="home-visit__label">Godziny otwarcia</span><span>Do potwierdzenia telefonicznie.</span></li>
            </ul>
            <div class="home-visit__actions">
              <a class="btn btn--secondary" href="${esc(VERIFIED.directionsHref)}" target="_blank" rel="noopener noreferrer">Otwórz wskazówki dojazdu</a>
            </div>
          </div>
        </div>
      </section>

      <section class="home-final" aria-labelledby="home-final-title">
        <div class="container home-final__inner">
          <div>
            <p class="home-kicker">Na początek</p>
            <h2 id="home-final-title" class="home-heading">Zacznij od menu, resztę ustalisz jednym telefonem.</h2>
          </div>
          <div class="home-actions">
            <a class="btn btn--primary" href="/menu/">Zobacz menu</a>
            <a class="btn btn--secondary" href="${VERIFIED.phoneHref}">Zadzwoń</a>
          </div>
        </div>
      </section>
    </main>`;
}
