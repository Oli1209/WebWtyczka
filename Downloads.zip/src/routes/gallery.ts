const GALLERY_IMAGES = [
  {
    src: '/assets/photography/reference/Farina-fb-cover-960x685.jpg',
    alt: 'Atmosferyczne ujęcie lokalu Farina (dekoracja witryny z logo) — materiał referencyjny, niekoniecznie reprezentatywny dla całej kolekcji.',
    caption: 'Wnętrze/wystrój — materiał referencyjny (źródło: publiczne materiały Farina).',
    width: 960,
    height: 685,
  },
  {
    src: '/assets/photography/reference/Farina-fb-drink-526x693.jpg',
    alt: 'Napój serwowany w miedzianym kubku — materiał referencyjny.',
    caption: 'Detale — materiał referencyjny (proweniencja niepotwierdzona w pełni).',
    width: 526,
    height: 693,
  },
];

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function renderGalleryPage(): string {
  const items = GALLERY_IMAGES.map((img, idx) => `
    <figure class="gallery-item" data-gallery-item data-index="${idx}">
      <button class="gallery-item__button" type="button" aria-label="Powiększ zdjęcie ${idx + 1}">
        <img class="gallery-item__img" src="${escapeHtml(img.src)}" alt="${escapeHtml(img.alt)}" width="${img.width}" height="${img.height}" loading="lazy" decoding="async" />
      </button>
      <figcaption class="gallery-item__caption">${escapeHtml(img.caption)}</figcaption>
    </figure>
  `).join('');

  return `
    <main id="main-content" tabindex="-1">
      <section class="gallery-hero">
        <div class="container gallery-hero__inner">
          <div>
            <p class="gallery-kicker">Galeria</p>
            <h1 class="gallery-hero__title">Atmosfera Farina</h1>
            <p class="gallery-hero__lead">Galeria prezentuje wybrane materiały referencyjne. Dostępna kolekcja fotografii restauracji jest ograniczona — przedstawiamy ją w sposób oszczędny i uczciwy, bez uzupełniania pustych miejsc stockiem.</p>
          </div>
          <aside class="gallery-hero__aside">
            <p class="gallery-meta"><strong>Stan:</strong> Ograniczona kolekcja (materiały referencyjne)</p>
            <p class="gallery-meta">Prawa/autentyczność nie są w pełni zweryfikowane. Zdjęcia nie są przedstawiane jako kompletny dokument fotograficzny restauracji.</p>
          </aside>
        </div>
      </section>

      <section class="gallery-section">
        <div class="container">
          ${GALLERY_IMAGES.length > 0 ? `
            <div class="gallery-grid">
              ${items}
            </div>
          ` : `
            <div class="gallery-empty">
              <h2>Zdjęcia w przygotowaniu</h2>
              <p>Nie posiadamy wystarczającej liczby zweryfikowanych fotografii Farina, by stworzyć rozbudowaną galerię. Ta strona pozostaje celowo oszczędna — bez fałszywych zdjęć stockowych.</p>
              <div class="gallery-empty__actions">
                <a class="btn btn--primary" href="/menu/">Zobacz menu</a>
                <a class="btn btn--secondary" href="/o-nas/">Poznaj Farinę</a>
              </div>
            </div>
          `}
          <p class="gallery-footnote">Jeśli posiadasz autentyczne zdjęcia Farina i wyrażasz zgodę na ich wykorzystanie, można je dodać w przyszłości z odpowiednim oznaczeniem pochodzenia.</p>
        </div>
      </section>

      <div id="gallery-lightbox" class="gallery-lightbox" role="dialog" aria-modal="true" aria-labelledby="gallery-lightbox-title" tabindex="-1">
        <div class="gallery-lightbox__backdrop" data-gallery-close></div>
        <div class="gallery-lightbox__content" role="document">
          <button class="gallery-lightbox__close" type="button" aria-label="Zamknij podgląd" data-gallery-close>×</button>
          <figure class="gallery-lightbox__figure">
            <img id="gallery-lightbox-img" class="gallery-lightbox__img" src="" alt="" />
            <figcaption id="gallery-lightbox-caption" class="gallery-lightbox__caption"></figcaption>
          </figure>
          <button class="gallery-lightbox__nav gallery-lightbox__nav--prev" type="button" aria-label="Poprzednie zdjęcie" data-gallery-prev>‹</button>
          <button class="gallery-lightbox__nav gallery-lightbox__nav--next" type="button" aria-label="Następne zdjęcie" data-gallery-next>›</button>
          <span id="gallery-lightbox-title" class="visually-hidden">Podgląd zdjęcia</span>
        </div>
      </div>
    </main>
  `;
}

export function initGalleryPage(): void {
  const items = Array.from(document.querySelectorAll<HTMLElement>('[data-gallery-item]'));
  const lightbox = document.getElementById('gallery-lightbox');
  const img = document.getElementById('gallery-lightbox-img') as HTMLImageElement | null;
  const caption = document.getElementById('gallery-lightbox-caption');
  const prevBtn = document.querySelector<HTMLButtonElement>('[data-gallery-prev]');
  const nextBtn = document.querySelector<HTMLButtonElement>('[data-gallery-next]');
  const closeBtns = Array.from(document.querySelectorAll<HTMLElement>('[data-gallery-close]'));
  
  if (!lightbox || !img || !caption || items.length === 0) return;
  
  let currentIndex = 0;
  let lastFocused: HTMLElement | null = null;
  
  const data = [
    { src: '/assets/photography/reference/Farina-fb-cover-960x685.jpg', alt: 'Atmosferyczne ujęcie lokalu Farina (dekoracja witryny z logo) — materiał referencyjny', caption: 'Wnętrze/wystrój — materiał referencyjny' },
    { src: '/assets/photography/reference/Farina-fb-drink-526x693.jpg', alt: 'Napój serwowany w miedzianym kubku — materiał referencyjny', caption: 'Detale — materiał referencyjny' },
  ];
  
  const open = (index: number) => {
    currentIndex = index;
    lastFocused = document.activeElement as HTMLElement;
    img.src = data[index].src;
    img.alt = data[index].alt;
    caption.textContent = data[index].caption;
    lightbox.classList.add('is-open');
    document.body.style.overflow = 'hidden';
    const closeBtn = lightbox.querySelector<HTMLButtonElement>('.gallery-lightbox__close');
    closeBtn?.focus();
  };
  
  const close = () => {
    lightbox.classList.remove('is-open');
    document.body.style.overflow = '';
    lastFocused?.focus();
  };
  
  const show = (delta: number) => {
    currentIndex = (currentIndex + delta + data.length) % data.length;
    img.src = data[currentIndex].src;
    img.alt = data[currentIndex].alt;
    caption.textContent = data[currentIndex].caption;
  };
  
  items.forEach((item, idx) => {
    const btn = item.querySelector<HTMLButtonElement>('.gallery-item__button');
    btn?.addEventListener('click', () => open(idx));
  });
  
  prevBtn?.addEventListener('click', () => show(-1));
  nextBtn?.addEventListener('click', () => show(1));
  closeBtns.forEach(btn => btn.addEventListener('click', close));
  
  document.addEventListener('keydown', (e) => {
    if (!lightbox.classList.contains('is-open')) return;
    if (e.key === 'Escape') { e.preventDefault(); close(); }
    if (e.key === 'ArrowLeft') { e.preventDefault(); show(-1); }
    if (e.key === 'ArrowRight') { e.preventDefault(); show(1); }
    if (e.key === 'Tab') {
      const focusable = Array.from(lightbox.querySelectorAll<HTMLElement>('button:not([disabled])'));
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
}

