const VERIFIED = {
  name: 'Farina Wieluń',
  address: 'Kopernika 29, 98-300 Wieluń',
  phoneDisplay: '+48 729 883 035',
  phoneHref: 'tel:+48729883035',
  mapsUrl: 'https://maps.google.com/?q=Kopernika%2029%2C%2098-300%20Wielu%C5%84',
};

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function renderContactPage(): string {
  return `
    <main id="main-content" tabindex="-1">
      <section class="contact-hero">
        <div class="container contact-hero__inner">
          <div>
            <p class="contact-kicker">Kontakt</p>
            <h1 class="contact-hero__title">Znajdź nas i umów spotkanie przy stole</h1>
            <p class="contact-hero__lead">Najprościej zadzwonić lub wpaść pod adres. Informacje o godzinach otwarcia podamy telefonicznie.</p>
          </div>
        </div>
      </section>

      <section class="contact-section">
        <div class="container contact-grid">
          <div class="contact-card">
            <h2>Dane kontaktowe</h2>
            <address class="contact-address">
              <p class="contact-address__name">${escapeHtml(VERIFIED.name)}</p>
              <p>${escapeHtml(VERIFIED.address)}</p>
              <p><a href="${VERIFIED.phoneHref}">${escapeHtml(VERIFIED.phoneDisplay)}</a></p>
            </address>
            <div class="contact-block">
              <h3>Godziny otwarcia</h3>
              <p class="contact-muted">Godziny otwarcia — informacje telefonicznie.</p>
            </div>
            <div class="contact-block">
              <h3>Oferta</h3>
              <p>Na miejscu i na wynos. Kuchnia włoska / neapolitańska.</p>
            </div>
            <div class="contact-block">
              <h3>Rezerwacje / zamówienia</h3>
              <p class="contact-muted">Brak potwierdzonego systemu rezerwacji lub zamówień online. W sprawach rezerwacji prosimy kontaktować się telefonicznie.</p>
            </div>
            <div class="contact-actions">
              <a class="btn btn--primary" href="${VERIFIED.phoneHref}">Zadzwoń</a>
              <a class="btn btn--secondary" href="${VERIFIED.mapsUrl}" target="_blank" rel="noopener noreferrer">Wyznacz trasę</a>
            </div>
          </div>

          <div class="contact-map">
            <div class="contact-map__inner">
              <h2>Lokalizacja</h2>
              <p class="contact-muted">Kopernika 29, 98-300 Wieluń, Polska</p>
              <div class="contact-map__frame">
                <iframe
                  title="Mapa z lokalizacją Farina Wieluń, Kopernika 29"
                  src="https://maps.google.com/maps?q=Kopernika%2029%2C%2098-300%20Wielu%C5%84&z=16&output=embed"
                  width="600"
                  height="450"
                  style="border:0;"
                  allowfullscreen=""
                  loading="lazy"
                  referrerpolicy="no-referrer-when-downgrade"></iframe>
              </div>
              <p class="contact-note">Mapa osadzona na podstawie potwierdzonego adresu. Link do nawigacji prowadzi do zewnętrznej usługi mapowej.</p>
            </div>
          </div>
        </div>
      </section>

      <section class="contact-section contact-section--warm">
        <div class="container contact-cta">
          <div>
            <h2>Gotowi na wspólny stół?</h2>
            <p>Zapraszamy na pizzę, makaron i rozmowę. Menu dostępne online.</p>
          </div>
          <div class="contact-cta__actions">
            <a class="btn btn--primary" href="/menu/">Zobacz menu</a>
            <a class="btn btn--secondary" href="/o-nas/">Poznaj nas</a>
          </div>
        </div>
      </section>
    </main>
  `;
}

export function initContactPage(): void {
  // No form interactions - factual contact page only.
}

