import { getLangFromPath } from '../i18n/routes';

const VERIFIED = {
  name: 'Farina Wieluń',
  address: 'Kopernika 29, 98-300 Wieluń',
  phoneDisplay: '+48 729 883 035',
  phoneHref: 'tel:+48729883035',
  mapsUrl: 'https://maps.google.com/?q=Kopernika%2029%2C%2098-300%20Wielu%C5%84',
};

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function renderAboutPage(): string {
  const lang = getLangFromPath(location.pathname);
  return `
    <main id="main-content" tabindex="-1">
      <section class="about-hero">
        <div class="container about-hero__inner">
          <div>
            <p class="about-kicker">O nas</p>
            <h1 class="about-hero__title">Miejsce spotkań przy wspólnym stole</h1>
            <p class="about-hero__lead">Farina to rodzinnie tworzone miejsce na kulinarnej mapie Wielunia. Łączy włoską pasję do gotowania z polskim ciepłem — bez nadętego tonu, z naciskiem na gościnność i czas spędzony razem.</p>
          </div>
          <aside class="about-hero__aside" aria-label="Podstawowe informacje">
            <div class="about-fact">
              <p class="about-fact__label">Adres</p>
              <p class="about-fact__value">${escapeHtml(VERIFIED.address)}</p>
            </div>
            <div class="about-fact">
              <p class="about-fact__label">Telefon</p>
              <p class="about-fact__value"><a href="${VERIFIED.phoneHref}">${escapeHtml(VERIFIED.phoneDisplay)}</a></p>
            </div>
            <div class="about-fact">
              <p class="about-fact__label">Oferta</p>
              <p class="about-fact__value">Kuchnia włoska w stylu neapolitańskim · na miejscu i na wynos</p>
            </div>
          </aside>
        </div>
      </section>

      <section class="about-section">
        <div class="container about-grid">
          <div class="about-story">
            <p class="about-kicker">Charakter</p>
            <h2 class="about-heading">Rodzinne podejście, włoska pasja</h2>
            <p>Farina powstało z chęci stworzenia miejsca, gdzie można dobrze zjeść, poczuć się swobodnie i spędzić czas z bliskimi. W publicznym przedstawieniu restauracji podkreśla się, że jest to miejsce tworzone rodzinnie — przez Polkę i Włocha, przy czym Włoch gotuje włoskie dania od około trzydziestu lat.</p>
            <p>Najważniejsze dla Farina są goście i relacje. Nie chodzi o wywyższanie, tylko o hojność — duże porcje, autentyczny smak i rozmowy, które trwają dłużej przy stole.</p>
            <p>Po siedmiu latach działalności nadal liczy się przede wszystkim atmosfera: ciepło, swoboda i wspólne chwile.</p>
          </div>
          <div class="about-aside">
            <blockquote class="about-quote">
              <p>„Są tylko duże porcje i długie rozmowy. Nie odmierzamy makaronu linijką. Karmimy z serca.”</p>
            </blockquote>
            <p class="about-note">Filozofia wyrażona w duchu, w jakim przedstawia się Farina — bez niepotwierdzonych szczegółów biograficznych, w oryginalnym, polskim ujęciu.</p>
          </div>
        </div>
      </section>

      <section class="about-section about-section--warm">
        <div class="container about-split">
          <div>
            <p class="about-kicker">Kuchnia</p>
            <h2 class="about-heading">Pizza, pasta i więcej</h2>
            <p class="about-lead">Kuchnia neapolitańska w praktycznym, codziennym wydaniu. Menu skupia się na klasykach — od pizz po makarony — podawanych hojnymi porcjami.</p>
            <p>Dokładny skład historyczny restauracji nie jest w pełni udokumentowany w dostępnych materiałach. Zamiast wymyślać szczegóły, strona skupia się na tym, co potwierdzone: lokalizacja, kontakt, oferta (na miejscu i na wynos) oraz charakter miejsca oparty na publicznych informacjach.</p>
            <div class="about-actions">
              <a class="btn btn--primary" href="/menu/">Zobacz menu</a>
              <a class="btn btn--secondary" href="/kontakt/">Jak do nas trafić</a>
            </div>
          </div>
          <div class="about-card">
            <h3>Warto wiedzieć</h3>
            <ul class="about-list">
              <li><strong>Adres:</strong> ${escapeHtml(VERIFIED.address)}</li>
              <li><strong>Telefon:</strong> <a href="${VERIFIED.phoneHref}">${escapeHtml(VERIFIED.phoneDisplay)}</a></li>
              <li><strong>Rodzaj:</strong> Restauracja włoska / neapolitańska</li>
              <li><strong>Usługi:</strong> Na miejscu, na wynos</li>
              <li><strong>Godziny otwarcia:</strong> Informacje telefonicznie</li>
            </ul>
            <p class="about-note">Nie wszystkie szczegóły (data założenia, właściciele, historia) są potwierdzone w dostępnych źródłach — zostały pominięte, by zachować faktyczność.</p>
          </div>
        </div>
      </section>

      <section class="about-section">
        <div class="container about-cta">
          <div>
            <p class="about-kicker">Zapraszamy</p>
            <h2 class="about-heading">Ciepło, które chce się podzielić</h2>
            <p class="about-lead">Najlepiej poznać Farinę przy stole. Serdecznie zapraszamy na pizzę, makaron i rozmowę.</p>
          </div>
          <div class="about-cta__actions">
            <a class="btn btn--primary" href="/menu/">Przejrzyj menu</a>
            <a class="btn btn--secondary" href="/galeria/">Zobacz galerię</a>
            <a class="btn btn--secondary" href="/kontakt/">Kontakt i dojazd</a>
          </div>
        </div>
      </section>
    </main>
  `;
}

export function initAboutPage(): void {
  // No complex interactions required for About page.
}

