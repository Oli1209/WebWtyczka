# Menu data foundation (PROMPT 2 — strategy only)

**Do not implement the complete menu UI or rewrite menu data in this stage.**

## Source of truth
- `WebsitesVAULT/06 - PROJECTS/Farina Wieluń/Farina - Menu Source Data.md` — 91 items, 12 sections, 4 pizza addition groups (Phase 0 verified).
- `Farina - Menu Data Quality.md` — unresolved issues. **DQ-09 and DQ-11 remain unresolved and must not be silently changed or presented as verified.**

## Planned technical integration (future PROMPT 4)
- Create a single typed menu data module under `src/data/menu/` (or equivalent) consumed by route/page components.
- Structure: `sections[]` in approved order (Antipasti, Zupy, Pasta, Pasta Fresca, Pizza, Dodatki do pizzy, Dania główne, Sałatki, Napoje bezalkoholowe, Herbaty, Desery, Napoje alkoholowe) with stable IDs/anchors.
- Each item: `id`, `name`, `description?`, `priceLabel` (authoritative display) and optional numeric `price` metadata only if it never disagrees; `portion?`, `sizes?`, `note?`. Preserve source spellings/capitalisation (`FW-23`).
- Pizza additions: separate collection with 4 price groups, rendered once and clearly associated with pizza — never repeated per pizza item.
- PL/EN: Polish source fields first. English fields may be added as approved translations (`translations.en` or parallel localized structures) without duplicating page components (`FW-03/FW-16`). No invented translations, no invented allergens/dietary/popularity labels.
- Rendering: full menu in HTML for no-JS readability; search/filter as progressive enhancement (future). Anchors required.

## Prohibited
- Fake allergens, dietary badges, popularity indicators, ordering actions.
- Correcting DQ-09/DQ-11 or source data without verified owner decision.
- External CMS/API dependencies.
