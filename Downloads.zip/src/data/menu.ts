/**
 * Structured menu data — derived from Farina - Menu Source Data (Vault).
 * Source strings preserved exactly (names, descriptions, ingredients, prices, order).
 * DQ-09/DQ-11 remain unresolved and identifiable via dataQuality markers; not exposed to visitors.
 */

export type DataQualityRef = 'DQ-09' | 'DQ-11';

export interface MenuItem {
  id: string;
  name: string;
  price: string;
  description?: string;
  note?: string;
  dataQuality?: DataQualityRef[];
}

export interface MenuCategory {
  id: string;
  number: string;
  name: string;
  subtitle?: string;
  items: MenuItem[];
}

export interface AdditionGroup {
  id: string;
  price: string;
  items: string[];
}

export interface MenuData {
  categories: MenuCategory[];
  additionGroups: AdditionGroup[];
  menuNotes: string[];
}

function slugify(s: string): string {
  return s
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

function item(cat: string, index: number, name: string, price: string, description?: string, dataQuality?: DataQualityRef[]): MenuItem {
  return {
    id: `${slugify(cat)}-${String(index).padStart(2, '0')}`,
    name,
    price,
    ...(description ? { description } : {}),
    ...(dataQuality ? { dataQuality } : {}),
  };
}

export const menuData: MenuData = {
  categories: [
    {
      id: 'antipasti', number: '01', name: 'Antipasti',
      items: [
        item('Antipasti', 1, 'BRUSCHETTA AL POMODORO (3 szt.)', '16 zł', 'Grzanki, pomidory, czosnek, oliwa extra vergine, oregano.'),
        item('Antipasti', 2, 'CARPACCIO DI BRESCAOLA', '49 zł', 'Cienkie plastry polędwicy wołowej na liściach rucoli, pomidorki cherry, kapary, Grana Padano, oliwa extra vergine.'),
        item('Antipasti', 3, 'BURRATA CON PROSCIUTTO DI PARMA', '39 zł', 'Delikatny włoski ser pochodzący z Apuglii podany w towarzystwie szynki parmeńskiej.'),
        item('Antipasti', 4, 'ANTIPASTO MISTO ITALINO x 2 PERSONE', '58 zł', 'Mix wędlin i serów włoskich podanych z marynatami lub konfiturami (dla 2 osób).'),
        item('Antipasti', 5, 'ZUPETTA DI FRUTTI DI MARE', '42 zł', 'Małże, pomidory, czosnek, peperoncino, natka pietruszki, chrupiące grzanki.'),
        item('Antipasti', 6, 'GAMBERETTI ARGENTINI XXL (5 szt.)', '56 zł', 'Krewetki argentyńskie w sosie pomidorowym z dodatkiem czarnych oliwek, owoców kaparów i natki pietruszki.'),
      ],
    },
    {
      id: 'pasta', number: '02', name: 'Pasta',
      items: [
        item('Pasta', 1, 'SPAGHETTI ALLA CARBONARA', '38 zł', 'Quanciale, żółtko, Grana Padano, pieprz.'),
        item('Pasta', 2, 'TAGLIATELLE FILETTO E FUNGHI', '40 zł', 'Polędwiczka wieprzowa, sos kurkowo-śmietanowy, cebula, natka pietruszki, Grana Padano.'),
        item('Pasta', 3, 'SPAGHETTI BOLOGNESE', '38 zł', 'Mięsny sos z dodatkiem mięsa mielonego i sosu pomidorowego na wywarze z warzyw.'),
        item('Pasta', 4, "PENNE ALL'ARRABBIATA", '36 zł', 'Pancetta, sos pomidorowy, peperoncino, czosnek, Grana Padano.'),
        item('Pasta', 5, 'PENNE ALLA SICILIANA', '36 zł', 'Sos pomidorowy, bakłażan, mozzarella, bazylia, Grana Padano.'),
        item('Pasta', 6, 'RIGATONI ALLA ORTOLANA', '36 zł', 'Bakłażan, cukinia, papryka, pomidory, śmietana, Grana Padano.'),
        item('Pasta', 7, 'SPAGHETTI ZUCCHINE E GAMBERETTI', '45 zł', 'Cukinia, krewetki, pomidory, oliwa extra vergine, czosnek, peperoncino, natka pietruszki.'),
        item('Pasta', 8, 'LINGUINI AI FRUTTI DI MARE', '45 zł', 'Kalmary, krewetki, małże, mule, pomidory, oliwa extra vergine, czosnek, peperoncino, natka pietruszki.'),
      ],
    },
    {
      id: 'pasta-ripiena', number: '03', name: 'Pasta Ripiena', subtitle: 'makaron nadziewany',
      items: [
        item('Pasta Ripiena', 1, 'RAVIOLI CREMA GORGONZOLA E NOCI', '43 zł', 'Pierożki ravioli z kremem gorgonzola, ricottą, śmietaną, orzechami włoskimi, Grana Padano.'),
        item('Pasta Ripiena', 2, 'RAVIOLI SPINACI E RICOTTA', '43 zł', 'Rzemieślnicze zielone ravioli nadziewane szpinakiem, ricottą i Grana Padano w kremowym sosie szpinakowym.'),
        item('Pasta Ripiena', 3, 'RAVIOLI FUNGHI PORCINI E RICOTTA', '43 zł', 'Rzemieślnicze ravioli z borowikami, ricottą i Grana Padano w kremowym sosie borowikowym.'),
        item('Pasta Ripiena', 4, 'PASTA RIPIENA CON CREMA DI TARTUFO', '43 zł', 'Makaron nadziewany parmezanem z kremem z czarnej trufli.'),
        item('Pasta Ripiena', 5, 'GNOCCHI AI QUATRO FORMAGGI', '40 zł', 'Małe ziemniaczane kłeseczki w kremowym sosie 4 sery.'),
      ],
    },
    {
      id: 'insalate', number: '04', name: 'Insalate',
      items: [
        item('Insalate', 1, 'INSALATA CON POLLO', '35 zł', 'Mix sałat, kurczak, pomidor, ogórek, kukurydza, czerwona cebula, sos musztardowy.'),
        item('Insalate', 2, 'INSALATA NOCI E PERA', '35 zł', 'Mix sałat, ser typu lazur, orzechy włoskie, gruszka, sos miodowo-balsamiczny.'),
        item('Insalate', 3, 'INSALATA FAVITA', '35 zł', 'Pomidor, ser typu favita, suszone pomidory, czarne oliwki, owoce kaparów, oregano, oliwa extra vergine.'),
        item('Insalate', 4, 'INSALATA CON TONNO', '35 zł', 'Mix sałat, tuńczyk, czarne oliwki, owoce kaparów, czerwona cebula, oliwa extra vergine.'),
        item('Insalate', 5, 'INSALATA CON GAMBARETTI', '40 zł', 'Rucola, krewetki 31/40, płatki Grana Padano, oliwa extra vergine, krem balsamiczny.'),
      ],
    },
    {
      id: 'pizza', number: '05', name: 'Pizza', subtitle: 'ok. 32 cm',
      items: [
        item('Pizza', 1, 'MARGHERITA', '30 zł', 'Sos pomidorowy, mozzarella, bazylia.'),
        item('Pizza', 2, 'COTTO', '32 zł', 'Sos pomidorowy, mozzarella, szynka.'),
        item('Pizza', 3, 'COTTO E FUNGHI', '35 zł', 'Sos pomidorowy, mozzarella, szynka, pieczarki.'),
        item('Pizza', 4, 'CAPRICCIOSA', '40 zł', 'Sos pomidorowy, mozzarella, szynka, pieczarki, biała kiełbasa, czarne oliwki.'),
        item('Pizza', 5, 'SALAME E PAPRICA', '38 zł', 'Sos pomidorowy, mozzarella, salami milanese, papryka.'),
        item('Pizza', 6, 'CAPRESE (bianca)', '35 zł', 'Mozzarella, pomidorki cherry, bazylia.'),
        item('Pizza', 7, 'FARINA', '43 zł', 'Sos pomidorowy, mozzarella, szynka parmeńska, pomidorki cherry, rucola, Grana Padano.'),
        item('Pizza', 8, 'HAWAII', '35 zł', 'Sos pomidorowy, mozzarella, szynka, ananas, kukurydza.'),
        item('Pizza', 9, 'QUATRO FORMAGGI CON RUCCOLA', '38 zł', 'Sos pomidorowy, mozzarella, gorgonzola, emental, Grana Padano, rucola.'),
        item('Pizza', 10, 'VESUVIO', '38 zł', 'Sos pomidorowy, mozzarella, salami piccante, papryczki jalapeno.'),
        item('Pizza', 11, 'ROMANA', '38 zł', 'Sos pomidorowy, mozzarella, boczek, czerwona cebula, zielone oliwki.'),
        item('Pizza', 12, 'SICILIANA', '38 zł', 'Sos pomidorowy, mozzarella, tuńczyk, czerwona cebula, czarne oliwki.'),
        item('Pizza', 13, 'GORGONZOLA, PERA E NOCI (bianca)', '42 zł', 'Mozzarella, gruszka, ser gorgonzola, orzechy włoskie.'),
        item('Pizza', 14, 'PIZZA SPIANATA E MASCARPONE', '43 zł', 'Sos pomidorowy, mozzarella, salami spianata piccante, mascarpone, rucola.'),
        item('Pizza', 15, 'PIZZA ORTOLANA (bianca)', '38 zł', 'Mozzarella, bakłażan, cukinia, papryka, pomidory.'),
        item('Pizza', 16, 'PIZZA BRESKAOLA (bianca)', '43 zł', 'Mozzarella, bresaola (długodojrzewająca wołowina), pomidorki cherry, szpinak baby, płatki Grana Padano.'),
        item('Pizza', 17, 'PIZZA PANCETTA (bianca)', '43 zł', 'Mozzarella, włoski boczek dojrzewający, czerwona cebula, pomidorki cherry, pieprz.'),
        item('Pizza', 18, 'FRUTTI DI MARE', '45 zł', 'Sos pomidorowy, mozzarella, mix owoców morza, czosnek, peperoncino, pietruszka.'),
      ],
    },
    {
      id: 'bevande-calde', number: '06', name: 'Bevande Calde', subtitle: 'napoje gorące',
      items: [
        item('Bevande Calde', 1, 'Espresso', '8 zł'),
        item('Bevande Calde', 2, 'Espresso Doppio', '12 zł'),
        item('Bevande Calde', 3, 'Caffe Americano', '10 zł'),
        item('Bevande Calde', 4, 'Cappuccino', '12 zł'),
        item('Bevande Calde', 5, 'Caffe Latte', '12 zł'),
        item('Bevande Calde', 6, 'Caffe Latte Smakowe', '14 zł', '(zapytaj kelnera o dostępne smaki)'),
        item('Bevande Calde', 7, 'Te herbata', '9 zł'),
      ],
    },
    {
      id: 'bevande-fredde', number: '07', name: 'Bevande Fredde', subtitle: 'napoje zimne',
      items: [
        item('Bevande Fredde', 1, 'Crodino', '9 zł', '100 ml (aperitif bezalkoholowy)'),
        item('Bevande Fredde', 2, 'Oran Soda', '10 zł', '330 ml (napój o smaku pomarańczowym)'),
        item('Bevande Fredde', 3, 'Lemon Soda', '10 zł', '330 ml (napój o smaku cytrynowym)'),
        item('Bevande Fredde', 4, 'San Pellegrino Chino', '10 zł', '330 ml (napój o smaku sycylijskiej gorzkiej pomarańczy)'),
        item('Bevande Fredde', 5, 'Coca-Cola, Coca-Cola Zero, Fanta, Sprite, Kinley Tonic', '8,50 zł', '250 ml'),
        item('Bevande Fredde', 6, 'Cappy', '8,50 zł', '250 ml'),
        item('Bevande Fredde', 7, 'Naturalna woda niegazowana Kropla Beskidu', '7,50 zł', '330 ml'),
        item('Bevande Fredde', 8, 'Naturalna woda mineralna gazowana Kropla Beskidu', '7,50 zł', '330 ml'),
      ],
    },
    {
      id: 'dolci', number: '08', name: 'Dolci', subtitle: 'desery',
      items: [
        item('Dolci', 1, 'Tiramisu in Coppa', '15 zł', 'Biszkopty, kawa, mascarpone.'),
        item('Dolci', 2, 'Panna Cotta', '15 zł', 'Klasyczny włoski deser ze śmietanki z polewą i owocami sezonowymi.'),
        item('Dolci', 3, 'Cannoli Siciliani', '20 zł', 'Deser sycylijski — kruche rurki nadziewane ricottą i kruszoną pistacją.'),
      ],
    },
    {
      id: 'piwo', number: '09', name: 'Piwo / piwa włoskie',
      items: [
        item('Piwo', 1, 'Żywiec', '11 zł', '500 ml'),
        item('Piwo', 2, 'Żywiec Białe', '11 zł', '500 ml'),
        item('Piwo', 3, 'Żywiec Porter', '11 zł', '500 ml'),
        item('Piwo', 4, 'Warka Jasne Pełne', '11 zł', '500 ml'),
        item('Piwo', 5, 'Warka Strong', '11 zł', '500 ml'),
        item('Piwo', 6, 'Książęce Pszeniczne', '11 zł', '500 ml'),
        item('Piwo', 7, 'Heineken', '11 zł', '500 ml'),
        item('Piwo', 8, 'Heineken 0%', '11 zł', '500 ml'),
        item('Piwo', 9, 'Piwo smakowe 0%', '11 zł', '500 ml'),
        item('Piwo', 10, 'Birra Moretti', '18 zł / 12 zł', '660 ml / 330 ml'),
        item('Piwo', 11, 'Nastro Azzurro', '18 zł / 12 zł', '660 ml / 330 ml'),
      ],
    },
    {
      id: 'vino-della-casa', number: '10', name: 'Vino della Casa', subtitle: 'wino domowe',
      items: [
        item('Vino della Casa', 1, 'Wino białe wytrawne', '12 zł', '125 ml'),
        item('Vino della Casa', 2, 'Wino białe półsłodkie', '12 zł', '125 ml'),
        item('Vino della Casa', 3, 'Wino czerwone wytrawne', '12 zł', '125 ml'),
        item('Vino della Casa', 4, 'Karafka wina stołowego (Della Casa)', '60 zł', '700 ml'),
      ],
    },
    {
      id: 'drinki', number: '11', name: 'Drinki',
      items: [
        item('Drinki', 1, 'Mohito', '25 zł', '(40ml biały rum / sprite / cukier trzcinowy / limonka / mięta)'),
        item('Drinki', 2, 'Aperol Spritz', '25 zł', '(80ml aperol / prosecco / sprite / pomarańcza)'),
        item('Drinki', 3, 'Żar Tropików', '25 zł', '(40ml biały rum / blue curacao / sok pomarańczowy)'),
        item('Drinki', 4, 'Błękitna Laguna', '25 zł', '(40ml biała wódka / blue curacao / napój o smaku limonki)'),
        item('Drinki', 5, 'Cuba Libre', '23 zł', '(40ml biały rum / coca-cola)'),
        item('Drinki', 6, 'Mimoza', '20 zł', '(40ml wino musujące / sok pomarańczowy)'),
        item('Drinki', 7, 'Hugo', '25 zł', '(120ml wino musujące / sok z limonki / syrop z czarnego bzu / woda gazowana)'),
        item('Drinki', 8, 'Gin & Tonic', '23 zł', '(40ml gin / tonic)'),
        item('Drinki', 9, 'Wściekły Pies', '9 zł', '(40ml biała wódka / sok malinowy / tabasco)', ['DQ-11']),
        item('Drinki', 10, 'Grzaniec', '15 zł', '(125ml korzenne grzane wino z pomarańczą)'),
      ],
    },
    {
      id: 'drink-bar-bezalkoholowy', number: '12', name: 'Drink bar bezalkoholowy',
      items: [
        item('Drink bar bezalkoholowy', 1, 'Mojito 0%', '20 zł', '(sprite / limonka / cukier trzcinowy / mięta)'),
        item('Drink bar bezalkoholowy', 2, 'Aperol Spritz 0%', '23 zł', '(80ml Aperol Free / Prosecco / woda gazowana / pomarańcza)', ['DQ-09']),
        item('Drink bar bezalkoholowy', 3, 'Gin Tonic 0%', '23 zł', '(40ml gin free / tonic)'),
        item('Drink bar bezalkoholowy', 4, 'Hugo 0%', '25 zł', '(120ml wino musujące bezalkoholowe / sok z limonki / syrop z czarnego bzu / woda gazowana)'),
        item('Drink bar bezalkoholowy', 5, 'Blue Curacao 0%', '23 zł', '(40ml blue curacao bezalkoholowe / napój o smaku limonki / woda gazowana)'),
        item('Drink bar bezalkoholowy', 6, 'Grzaniec 0%', '15 zł', '(125ml korzenne grzane wino bezalkoholowe z pomarańczą)'),
      ],
    },
  ],
  additionGroups: [
    { id: 'dodatki-5', price: '5 zł', items: ['Ananas', 'pieczarki', 'papryka', 'pomidor', 'rucola', 'czerwona cebula', 'kukurydza', 'bakłażan', 'cukinia', 'papryka jalapeno'] },
    { id: 'dodatki-6', price: '6 zł', items: ['Biała kiełbasa', 'szynka', 'kurczak', 'boczek', 'oliwki', 'pomidorki cherry', 'salami', 'orzechy włoskie', 'owoce kaparów'] },
    { id: 'dodatki-8', price: '8 zł', items: ['Mozzarella', 'gorgonzola', 'mascarpone', 'Grana Padano', 'tuńczyk', 'szynka parmeńska', 'bresaola', 'pancetta', 'salami spianata'] },
    { id: 'dodatki-10', price: '10 zł', items: ['Owoce morza'] },
  ],
  menuNotes: [
    'Biodegradable takeaway packaging: 2 zł per item.',
    'Allergen information is available from restaurant staff.',
  ],
};

export interface ValidationResult {
  ok: boolean;
  categoryCount: number;
  primaryEntryCount: number;
  additionGroupCount: number;
  additionIngredientCount: number;
  dq09Identified: boolean;
  dq11Identified: boolean;
  categoryOrderOk: boolean;
  uniqueIds: boolean;
  issues: string[];
}

export function validateMenu(data: MenuData = menuData): ValidationResult {
  const issues: string[] = [];
  const expectedOrder = ['Antipasti','Pasta','Pasta Ripiena','Insalate','Pizza','Bevande Calde','Bevande Fredde','Dolci','Piwo / piwa włoskie','Vino della Casa','Drinki','Drink bar bezalkoholowy'];
  const expectedCounts = [6,8,5,5,18,7,8,3,11,4,10,6];
  const expectedAddCounts = [10,9,9,1];
  if (data.categories.length !== 12) issues.push(`Expected 12 categories, got ${data.categories.length}`);
  const categoryOrderOk = data.categories.map(c => c.name).join('|') === expectedOrder.join('|');
  if (!categoryOrderOk) issues.push('Category order does not match source');
  data.categories.forEach((c, i) => {
    if (c.items.length !== expectedCounts[i]) issues.push(`${c.name}: expected ${expectedCounts[i]} items, got ${c.items.length}`);
    c.items.forEach((it, j) => { if (!it.name || !it.price) issues.push(`${c.name}[${j}]: missing name/price`); });
  });
  if (data.additionGroups.length !== 4) issues.push(`Expected 4 addition groups, got ${data.additionGroups.length}`);
  data.additionGroups.forEach((g, i) => {
    if (g.items.length !== expectedAddCounts[i]) issues.push(`Addition ${g.price}: expected ${expectedAddCounts[i]}, got ${g.items.length}`);
  });
  const allIds = [...data.categories.flatMap(c => c.items.map(i => i.id)), ...data.categories.map(c => c.id)];
  const uniqueIds = new Set(allIds).size === allIds.length;
  if (!uniqueIds) issues.push('Duplicate IDs detected');
  const dq09 = data.categories.flatMap(c => c.items).find(i => i.name === 'Aperol Spritz 0%');
  const dq11 = data.categories.flatMap(c => c.items).find(i => i.name === 'Wściekły Pies');
  const dq09Identified = !!dq09?.dataQuality?.includes('DQ-09') && dq09?.description?.includes('Prosecco') === true && dq09.price === '23 zł';
  const dq11Identified = !!dq11?.dataQuality?.includes('DQ-11') && dq11.price === '9 zł';
  if (!dq09Identified) issues.push('DQ-09 not preserved/identified as expected');
  if (!dq11Identified) issues.push('DQ-11 not preserved/identified as expected');
  const primaryEntryCount = data.categories.reduce((n, c) => n + c.items.length, 0);
  const additionIngredientCount = data.additionGroups.reduce((n, g) => n + g.items.length, 0);
  if (primaryEntryCount !== 91) issues.push(`Expected 91 primary entries, got ${primaryEntryCount}`);
  if (additionIngredientCount !== 29) issues.push(`Expected 29 addition ingredients, got ${additionIngredientCount}`);
  return { ok: issues.length === 0, categoryCount: data.categories.length, primaryEntryCount, additionGroupCount: data.additionGroups.length, additionIngredientCount, dq09Identified, dq11Identified, categoryOrderOk, uniqueIds, issues };
}
