export type Lang = 'pl' | 'en';
export type PageKey = 'home' | 'menu' | 'about' | 'flavours' | 'gallery' | 'contact' | 'not-found';

export interface RouteDef {
  key: PageKey;
  pl: string;
  en: string;
  labelKey: string;
  conditional?: boolean;
}

/**
 * Canonical PL routes (PROMPT 2 foundation). EN equivalents are reserved for FW-16.
 * Polish is default; EN content is not implemented in this stage.
 */
export const routes: RouteDef[] = [
  { key: 'home', pl: '/', en: '/en/', labelKey: 'nav.home' },
  { key: 'menu', pl: '/menu/', en: '/en/menu/', labelKey: 'nav.menu' },
  { key: 'about', pl: '/o-nas/', en: '/en/about/', labelKey: 'nav.about' },
  { key: 'flavours', pl: '/nasze-smaki/', en: '/en/our-flavours/', labelKey: 'nav.flavours', conditional: true },
  { key: 'gallery', pl: '/galeria/', en: '/en/gallery/', labelKey: 'nav.gallery' },
  { key: 'contact', pl: '/kontakt/', en: '/en/contact/', labelKey: 'nav.contact' },
];

export function normalizePath(pathname: string): string {
  if (!pathname || pathname === '/') return '/';
  const withSlash = pathname.endsWith('/') ? pathname : `${pathname}/`;
  return withSlash.replace(/\/index\.html\/?$/i, '/');
}

export function getCurrentRoute(pathname: string): RouteDef | undefined {
  const p = normalizePath(pathname);
  return routes.find((r) => r.pl === p || r.en === p);
}

export function getLangFromPath(pathname: string): Lang {
  return normalizePath(pathname).startsWith('/en/') ? 'en' : 'pl';
}

export function getLocalizedPath(key: PageKey, lang: Lang): string {
  const route = routes.find((r) => r.key === key);
  if (!route) return lang === 'en' ? '/en/' : '/';
  return lang === 'en' ? route.en : route.pl;
}
