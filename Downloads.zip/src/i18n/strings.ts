import type { Lang } from './routes';

export const strings = {
  pl: {
    'nav.home': 'Start',
    'nav.menu': 'Menu',
    'nav.about': 'O nas',
    'nav.flavours': 'Nasze smaki',
    'nav.gallery': 'Galeria',
    'nav.contact': 'Kontakt',
    'nav.main': 'Nawigacja główna',
    'nav.open': 'Otwórz menu',
    'nav.close': 'Zamknij menu',
    'lang.label': 'Język',
    'lang.pl': 'PL',
    'lang.en': 'EN',
    'lang.enPending': 'EN (treści w przygotowaniu)',
    'skip.content': 'Przejdź do treści',
    'footer.rights': 'Farina Wieluń — fundament strony (etap deweloperski).',
    'shell.status': 'Etap PROMPT 2: fundament techniczny. Treści strony zostaną wdrożone w kolejnych promptach.',
    'shell.conditional': 'Strona warunkowa: treść zależy od dostępnych materiałów i decyzji projektowych.',
  },
  en: {
    // EN UI content is intentionally incomplete in PROMPT 2 (FW-16). Do not treat as full translation.
    'nav.home': 'Home',
    'nav.menu': 'Menu',
    'nav.about': 'About',
    'nav.flavours': 'Our Flavours',
    'nav.gallery': 'Gallery',
    'nav.contact': 'Contact',
    'nav.main': 'Main navigation',
    'nav.open': 'Open menu',
    'nav.close': 'Close menu',
    'lang.label': 'Language',
    'lang.pl': 'PL',
    'lang.en': 'EN',
    'lang.enPending': 'EN (content pending)',
    'skip.content': 'Skip to content',
    'footer.rights': 'Farina Wieluń — development foundation.',
    'shell.status': 'PROMPT 2 foundation stage. Page content will be implemented in later prompts.',
    'shell.conditional': 'Conditional page: content depends on assets and design decisions.',
  },
} as const satisfies Record<Lang, Record<string, string>>;

export type StringKey = keyof typeof strings.pl;

export function t(lang: Lang, key: StringKey): string {
  return strings[lang][key] ?? strings.pl[key] ?? key;
}
