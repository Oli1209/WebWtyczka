import './styles/base.css';
import './styles/layout.css';
import './styles/components.css';
import './styles/home.css';
import './styles/menu.css';
import './styles/about.css';
import './styles/gallery.css';
import './styles/contact.css';

import { getCurrentRoute, getLangFromPath, getLocalizedPath, normalizePath, routes, type Lang, type PageKey } from './i18n/routes';
import { t, type StringKey } from './i18n/strings';
import { renderHomePage } from './routes/home';
import { initMenuPage, renderMenuPage } from './routes/menu';
import { initAboutPage, renderAboutPage } from './routes/about';
import { initGalleryPage, renderGalleryPage } from './routes/gallery';
import { initContactPage, renderContactPage } from './routes/contact';

const VERIFIED = {
  name: 'Farina Wieluń',
  address: 'Kopernika 29, 98-300 Wieluń',
  phoneDisplay: '+48 729 883 035',
  phoneHref: 'tel:+48729883035',
};

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function navLinks(lang: Lang, currentKey: PageKey): string {
  return routes
    .filter((r) => r.key !== 'not-found' && !r.conditional)
    .map((r) => {
      const href = lang === 'en' ? r.en : r.pl; // EN routes reserved; links point to mapping but EN content is pending.
      const label = t(lang, r.labelKey as StringKey);
      const current = r.key === currentKey ? ' aria-current="page"' : '';
      return `<a href="${href}"${current}>${escapeHtml(label)}</a>`;
    })
    .join('');
}

function languageSwitcher(lang: Lang, compact = false): string {
  // PL default active. EN is intentionally unavailable as full content in PROMPT 2 (FW-16) — do not mislead.
  const enStatus = t(lang, 'lang.enPending');
  return `
    <div class="lang-switch ${compact ? 'lang-switch--compact' : ''}" aria-label="${escapeHtml(t(lang, 'lang.label'))}">
      <span class="lang-switch__label">${escapeHtml(t(lang, 'lang.label'))}:</span>
      <span class="lang-switch__item" aria-current="${lang === 'pl' ? 'true' : 'false'}" lang="pl">PL</span>
      <button type="button" class="lang-switch__btn" aria-disabled="true" title="${escapeHtml(enStatus)}" lang="en">EN</button>
      <span class="lang-switch__status">${escapeHtml(enStatus)}</span>
    </div>`;
}

function header(lang: Lang, currentKey: PageKey): string {
  const homeHref = getLocalizedPath('home', 'pl');
  const logoSrc = '/assets/brand/derived/Farina-logo-lockup-704x414.png';
  return `
    <header class="site-header">
      <div class="container site-header__inner">
        <a class="brand" href="${homeHref}" aria-label="Farina Wieluń — strona główna">
          <img class="brand__logo" src="${logoSrc}" alt="Farina — pasta e pizza" width="704" height="414" decoding="async" />
        </a>
        <nav class="nav-desktop" aria-label="${escapeHtml(t(lang, 'nav.main'))}">
          ${navLinks(lang, currentKey)}
        </nav>
        <div class="header-actions">
          ${languageSwitcher(lang, true)}
          <button type="button" class="menu-toggle" aria-expanded="false" aria-controls="mobile-nav" aria-label="${escapeHtml(t(lang, 'nav.open'))}">
            <span class="menu-toggle__text">Menu</span>
          </button>
        </div>
      </div>
      <div class="nav-mobile-wrap" id="mobile-nav" data-open="false">
        <nav class="nav-mobile" aria-label="${escapeHtml(t(lang, 'nav.main'))}">
          ${navLinks(lang, currentKey)}
          ${languageSwitcher(lang)}
        </nav>
      </div>
    </header>`;
}

function footer(lang: Lang): string {
  const links = routes
    .filter((r) => r.key !== 'not-found' && !r.conditional)
    .map((r) => `<li><a href="${r.pl}">${escapeHtml(t(lang, r.labelKey as StringKey))}</a></li>`)
    .join('');
  return `
    <footer class="site-footer">
      <div class="container site-footer__grid">
        <section aria-label="Dane kontaktowe">
          <h2 class="site-footer__title">Farina</h2>
          <address>
            <p class="site-footer__meta">${escapeHtml(VERIFIED.name)}</p>
            <p class="site-footer__meta">${escapeHtml(VERIFIED.address)}</p>
            <p class="site-footer__meta"><a href="${VERIFIED.phoneHref}">${escapeHtml(VERIFIED.phoneDisplay)}</a></p>
          </address>
          <p class="site-footer__meta">Godziny otwarcia: do potwierdzenia telefonicznie.</p>
        </section>
        <nav aria-label="Linki">
          <h2 class="site-footer__title" style="font-size:1.1rem;font-family:var(--font-body);font-weight:600;">Nawigacja</h2>
          <ul class="site-footer__list">${links}</ul>
        </nav>
        <section aria-label="Informacje">
          <h2 class="site-footer__title" style="font-size:1.1rem;font-family:var(--font-body);font-weight:600;">Informacje</h2>
          <p class="site-footer__meta">Prywatny projekt deweloperski (lokalny). Treści i materiały wymagają weryfikacji przed publikacją.</p>
        </section>
      </div>
      <div class="container site-footer__bottom">
        <p>${escapeHtml(t(lang, 'footer.rights'))}</p>
      </div>
    </footer>`;
}

function pageShell(page: PageKey, title: string, lang: Lang): string {
  const route = getCurrentRoute(location.pathname);
  const conditional = route?.conditional;
  const lead = conditional ? t(lang, 'shell.conditional') : t(lang, 'shell.status');
  return `
    <main id="main-content" tabindex="-1">
      <div class="container page-shell">
        <p class="page-shell__eyebrow">Etap deweloperski / ${escapeHtml(normalizePath(location.pathname))}</p>
        <h1 class="page-shell__title">${escapeHtml(title)}</h1>
        <p class="page-shell__status">${escapeHtml(lead)}</p>
      </div>
    </main>`;
}

function initMobileNav(): void {
  const toggle = document.querySelector<HTMLButtonElement>('.menu-toggle');
  const wrap = document.querySelector<HTMLElement>('#mobile-nav');
  if (!toggle || !wrap) return;
  const labelOpen = 'Otwórz menu';
  const labelClose = 'Zamknij menu';
  let lastFocused: HTMLElement | null = null;

  const focusableSelector = 'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])';

  const setOpen = (open: boolean) => {
    wrap.dataset.open = open ? 'true' : 'false';
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? labelClose : labelOpen);
    toggle.querySelector('.menu-toggle__text')!.textContent = open ? 'Zamknij' : 'Menu';
    document.body.classList.toggle('nav-open', open);
    if (open) {
      lastFocused = document.activeElement as HTMLElement;
      const first = wrap.querySelector<HTMLElement>(focusableSelector);
      first?.focus();
    } else {
      lastFocused?.focus?.();
    }
  };

  toggle.addEventListener('click', () => setOpen(wrap.dataset.open !== 'true'));
  wrap.addEventListener('click', (e) => {
    const target = e.target as HTMLElement;
    if (target.closest('a[href]')) setOpen(false);
  });
  document.addEventListener('keydown', (e) => {
    if (wrap.dataset.open !== 'true') return;
    if (e.key === 'Escape') {
      e.preventDefault();
      setOpen(false);
      return;
    }
    if (e.key === 'Tab') {
      const focusable = Array.from(wrap.querySelectorAll<HTMLElement>(focusableSelector)).filter((el) => !el.hasAttribute('disabled'));
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
  window.addEventListener('resize', () => {
    if (window.innerWidth >= 1024 && wrap.dataset.open === 'true') setOpen(false);
  });
}

function render(): void {
  const app = document.getElementById('app');
  if (!app) return;
  const page = (app.dataset.page as PageKey) || 'home';
  const title = app.dataset.pageTitle || 'Farina';
  const lang = getLangFromPath(location.pathname);
  document.documentElement.lang = lang;

  // Update skip link text by language (present in static HTML; keep in sync)
  const skip = document.querySelector<HTMLAnchorElement>('.skip-link');
  if (skip) skip.textContent = t(lang, 'skip.content');

  app.className = 'site-shell';
  const main =
    page === 'home' ? renderHomePage() :
    page === 'menu' ? renderMenuPage() :
    page === 'about' ? renderAboutPage() :
    page === 'gallery' ? renderGalleryPage() :
    page === 'contact' ? renderContactPage() :
    pageShell(page, title, lang);
  app.innerHTML = `${header(lang, page)}${main}${footer(lang)}`;
  initMobileNav();
  if (page === 'menu') initMenuPage();
  if (page === 'about') initAboutPage();
  if (page === 'gallery') initGalleryPage();
  if (page === 'contact') initContactPage();
}

render();
