import { defineConfig } from 'vite';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const rootDir = fileURLToPath(new URL('.', import.meta.url));

/**
 * Farina Wieluń — Vite multi-page foundation.
 * Static output, local dev, no backend. Route shells only in PROMPT 2.
 */
export default defineConfig({
  appType: 'mpa',
  server: {
    host: '127.0.0.1',
    port: 5173,
    strictPort: false,
  },
  preview: {
    host: '127.0.0.1',
    port: 4173,
    strictPort: false,
  },
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    rollupOptions: {
      input: {
        main: resolve(rootDir, 'index.html'),
        menu: resolve(rootDir, 'menu/index.html'),
        about: resolve(rootDir, 'o-nas/index.html'),
        flavours: resolve(rootDir, 'nasze-smaki/index.html'),
        gallery: resolve(rootDir, 'galeria/index.html'),
        contact: resolve(rootDir, 'kontakt/index.html'),
        notFound: resolve(rootDir, '404.html'),
      },
    },
  },
});
