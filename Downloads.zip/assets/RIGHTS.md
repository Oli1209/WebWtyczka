# Farina assets — rights warning

> Read this before using any file in this folder anywhere public.

**Nothing in this folder is licensed for publication.** Every file was retrieved on 2026-11-06 from a public source and is stored for private design work and portfolio preparation only. Public accessibility is not permission.

| File | Retrieved from | Rights status |
|---|---|---|
| `brand/source/Farina-logo-769x769.jpg` | Facebook CDN URL supplied by the project owner | `UNVERIFIED` — no written permission |
| `brand/derived/Farina-logo-lockup-704x414.png` | Crop of the file above (no retouching) | `UNVERIFIED` — inherits the original's status |
| `brand/derived/Farina-mark-heart-107x100.png` | Crop of the file above | `UNVERIFIED` — inherits the original's status |
| `photography/reference/Farina-fb-cover-960x685.jpg` | Farina's public Facebook page cover | `UNVERIFIED` — no written permission |
| `photography/reference/Farina-fb-drink-526x693.jpg` | Farina's public Facebook page image | `UNVERIFIED` — no written permission; EXIF reports "Screenshot", so its own origin is unconfirmed |

Rules:

1. Do not publish, deploy or share these files without written permission from the restaurant.
2. Do not recolour, redraw or "clean up" the logo. It is identity, not decoration.
3. Do not treat a Facebook or Google Maps upload as evidence of ownership; both platforms host material uploaded by third parties.
4. Originals are never modified. Derivatives are crops and are clearly named as such.

Provenance, technical measurements, permissions status and the full assessment live in the Vault:

`06 - PROJECTS/Farina Wieluń/Farina - Photography and Assets.md`
